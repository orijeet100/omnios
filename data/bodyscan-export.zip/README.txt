Body scan export - 3 scans (Visualize SDK 2.0.3)

export.json
  scans[] each with: memberId, name, pointCloudFile, pointCloudVertices,
  result{ scanId, occurredAt, modelVersion,
          subject{ gender, heightIn, weightLb, ageYears },
          measurements{ bodyFatPercent, bmi, leanMuscleMassLb, boneMineralContentLb,
                        girths{neckIn,waistIn,lowerWaistIn,hipIn}, smoothedGirths,
                        advanced{ waistHipRatio, waistHeightRatio, centralAdiposityIndex,
                                  fatMassIndex, skeletalMuscleIndex, musclePreservationIndex? },
                        bodyFatFormula, duration } }
  Units: inches / pounds. musclePreservationIndex is optional (absent for 2 of 3 scans).

pointclouds/<scanId>.ply
  Binary little-endian PLY point cloud of the body reconstruction.

Contains personal body-scan data. Share only with people who should see it.
